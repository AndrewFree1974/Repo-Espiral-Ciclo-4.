export default function UsuariosPage() {
    return (
        <div>
            <h1>UsersPage</h1>
        </div>
    )
}
