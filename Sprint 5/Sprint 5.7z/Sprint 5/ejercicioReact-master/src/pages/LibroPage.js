export default function LibroPage() {
    return (
        <div>
            <h1>LibroPage</h1>
        </div>
    )
}
 