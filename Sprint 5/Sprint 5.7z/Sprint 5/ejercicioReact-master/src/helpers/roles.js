const roles = {
    admin: 'admin',
    regular: 'regular',
};

export default roles;